package com.bashsupn.scheduleproject.executive

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bashsupn.scheduleproject.R

class DashboardExecutiv : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_executiv)
    }
}