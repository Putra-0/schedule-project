package com.bashsupn.scheduleproject.manager

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.cardview.widget.CardView
import com.bashsupn.scheduleproject.LoginActivity
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.sharedpreferences.PrefManager
import kotlinx.android.synthetic.main.activity_dashboard_manager.*

class DashboardManager : AppCompatActivity() {

    private lateinit var prefManager: PrefManager
    private val TIME_INTERVAL = 2000
    private var mBackPressed: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_manager)

        val projects = findViewById<CardView>(R.id.projects)
        projects.setOnClickListener{
            val Intent = Intent(this,Projects::class.java)
            startActivity(Intent)
        }
        val pelaksana = findViewById<CardView>(R.id.pelaksana)
        pelaksana.setOnClickListener{
            val Intent = Intent(this,Executives::class.java)
            startActivity(Intent)
        }
        val schedule = findViewById<CardView>(R.id.bali)
        schedule.setOnClickListener{
            val Intent = Intent(this,Schedule::class.java)
            startActivity(Intent)
        }

        prefManager = PrefManager(this)
        val token = prefManager.fetchAccessToken()

        if (token != null) {
        } else {
            toLogin()
        }
        logout.setOnClickListener {
            toLogin()
        }
    }

    fun toLogin() {
        prefManager.deleteAccessToken()

        Intent(this, LoginActivity::class.java).also {
            it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(it)
        }
    }
    override fun onBackPressed() {
        if (mBackPressed + TIME_INTERVAL > System.currentTimeMillis()) {
            super.onBackPressed()
            return
        } else {
            Toast.makeText(baseContext, "Tekan Back Sekali lagi untuk Keluar", Toast.LENGTH_SHORT)
                .show()
        }
        mBackPressed = System.currentTimeMillis()
    }
}