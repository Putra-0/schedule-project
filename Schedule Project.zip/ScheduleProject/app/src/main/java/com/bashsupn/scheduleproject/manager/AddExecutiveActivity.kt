package com.bashsupn.scheduleproject.manager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.api.RClient
import com.bashsupn.scheduleproject.databinding.ActivityAddExecutiveBinding
import com.bashsupn.scheduleproject.model.FormResponse
import com.bashsupn.scheduleproject.sharedpreferences.PrefManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddExecutiveActivity : AppCompatActivity() {

    private lateinit var prefManager: PrefManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_executive)

        SaveData()

    }

    private fun SaveData() {

        val etNama = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_nama_executive)
        val etEmail = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_email)
        val etPassword = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_password)
        val etPasswordConfirm = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_confirm_password)
        val btnSave = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_tambah_executive)

        btnSave.setOnClickListener {


            val nama = etNama.text.toString()
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val passwordConfirm = etPasswordConfirm.text.toString()

            val api = RClient.Create(this)
            val callData = api.createExecutive(nama, email, password, passwordConfirm)

            if (nama.isEmpty()) {
                etNama.error = "Nama tidak boleh kosong"
            }
            else if (email.isEmpty()) {
                etEmail.error = "Email tidak boleh kosong"
            }
            else if (password.isEmpty()) {
                etPassword.error = "Password tidak boleh kosong"
            }
            else if (passwordConfirm.isEmpty()) {
                etPasswordConfirm.error = "Password tidak boleh kosong"
            }else if (password != passwordConfirm) {
                etPasswordConfirm.error = "Password tidak sama"
            } else {
                callData.enqueue(object : Callback<FormResponse> {
                    override fun onResponse(
                        call: Call<FormResponse>,
                        response: Response<FormResponse>,
                    ) {
                        val data = response.body()
                        if (data?.status == true) {
                            Toast.makeText(this@AddExecutiveActivity, data.message, Toast.LENGTH_SHORT).show()
                            finish()
                        } else {
                            Toast.makeText(this@AddExecutiveActivity, "Data gagal ditambahkan", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: Call<FormResponse>, t: Throwable) {
                        Toast.makeText(this@AddExecutiveActivity, t.message, Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
    }

}