package com.bashsupn.scheduleproject.model

data class Manager(
    val created_at: String,
    val deleted_at: Any,
    val email: String,
    val email_verified_at: Any,
    val id: Int,
    val name: String,
    val updated_at: String
)