package com.bashsupn.scheduleproject.model

data class ProjectResponse(
    val data: ArrayList<Data>,
    val message: String,
    val status: String
)