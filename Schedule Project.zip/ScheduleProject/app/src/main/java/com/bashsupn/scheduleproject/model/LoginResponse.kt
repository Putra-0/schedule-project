package com.bashsupn.scheduleproject.model

data class LoginResponse(
    val manager: Manager,
    val status: Boolean,
    val message: String,
    val token: String
)