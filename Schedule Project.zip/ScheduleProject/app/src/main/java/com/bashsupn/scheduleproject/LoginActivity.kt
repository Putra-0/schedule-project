package com.bashsupn.scheduleproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.bashsupn.scheduleproject.api.RClient
import com.bashsupn.scheduleproject.manager.DashboardManager
import com.bashsupn.scheduleproject.model.LoginResponse
import com.bashsupn.scheduleproject.sharedpreferences.PrefManager
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var prefManager: PrefManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        prefManager = PrefManager(this)


        btnLogin.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                etEmail.error = "Email not empty"
                etPassword.error = "Password not empty"
                return@setOnClickListener
            }
            val api = RClient.Create(this)
            api.login(email, password).enqueue((object : Callback<LoginResponse>{
                override fun onResponse(
                    call : Call<LoginResponse>, response: Response<LoginResponse>) {
                    val respon = response.body()

                    if (respon != null) {
                            prefManager.saveAccessToken(respon.token)
                            val i = Intent(this@LoginActivity, DashboardManager::class.java)
                            Toast.makeText(
                                this@LoginActivity,
                                respon?.message,
                                Toast.LENGTH_LONG
                            ).show()
                            startActivity(i)
                            finish()
                    } else {
                        Toast.makeText(
                            this@LoginActivity,
                            "Email or Password is wrong",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    Toast.makeText(this@LoginActivity, t.localizedMessage, Toast.LENGTH_LONG).show()
                }
            }))
        }
    }
}