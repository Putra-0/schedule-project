package com.bashsupn.scheduleproject.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.model.Data
import com.bashsupn.scheduleproject.model.ProjectResponse

class AdapterProject(private val dataList: ArrayList<ProjectResponse>) : RecyclerView.Adapter<AdapterProject.ViewHolderData>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderData {
        val layout = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)

        return ViewHolderData(layout)
    }

    override fun onBindViewHolder(holder: ViewHolderData, position: Int) {

        val item = dataList[position]
        holder.nama.text = item.data[position].name
        holder.tanggal.text = item.data[position].created_at




//        holder.itemView.setOnClickListener {
//            val ctx = holder.context
//            val intent = Intent(ctx, DetailProject::class.java)
//            val a: String = item.gambar
//
//            intent.putExtra("id", item.id.toString())
//            intent.putExtra("tanggal", item.tanggal.toString())
//
//            ctx.startActivity(intent)
//
//        }
    }

    override fun getItemCount(): Int = dataList.size

    class ViewHolderData(itemView: View) : RecyclerView.ViewHolder(itemView) {



        val nama: TextView = itemView.findViewById(R.id.mTitle)
        val tanggal: TextView = itemView.findViewById(R.id.mTgl)
        val context = itemView.context
    }
}