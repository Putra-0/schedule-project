package com.bashsupn.scheduleproject.model

class FormResponse(
    val status : Boolean,
    val message : String,
) {
}