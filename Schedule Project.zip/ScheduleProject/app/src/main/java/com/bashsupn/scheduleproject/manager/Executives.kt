package com.bashsupn.scheduleproject.manager

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.adapter.AdapterExecutives
import com.bashsupn.scheduleproject.api.RClient
import com.bashsupn.scheduleproject.model.FormResponse
import com.bashsupn.scheduleproject.model.UserResponse
import com.bashsupn.scheduleproject.sharedpreferences.PrefManager
import kotlinx.android.synthetic.main.activity_executives.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Executives : AppCompatActivity() {

    private lateinit var prefManager: PrefManager
    lateinit var swipeRefreshLayout: SwipeRefreshLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_executives)
        getUser()

        swipeRefreshLayout = findViewById(R.id.swipe)
        swipeRefreshLayout.setOnRefreshListener {
            getUser()
            swipeRefreshLayout.isRefreshing=false
        }

        val btnAdd = findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.adBtnPelaksana)
        btnAdd.setOnClickListener {
            val intent = Intent(this, AddExecutiveActivity::class.java)
            startActivity(intent)
        }

    }

    private fun getUser() {
        prefManager = PrefManager(this)
        val api = RClient.Create(this)
        val listData = ArrayList<UserResponse>()
        val rvuser = findViewById<RecyclerView>(R.id.rv_user)
        rvuser.setHasFixedSize(true)
        rvuser.layoutManager = LinearLayoutManager(this)
        val callData = api.getUsers()

        callData.enqueue(object : Callback<ArrayList<UserResponse>>{
            override fun onResponse(
                call: Call<ArrayList<UserResponse>>,
                response: Response<ArrayList<UserResponse>>,
            ) {
                val data = response.body()
                data?.let { listData.addAll(it) }
                val adapterData = AdapterExecutives(listData)
                rvuser.adapter = adapterData
                Log.e("Data", data.toString())

            }

            override fun onFailure(call: Call<ArrayList<UserResponse>>, t: Throwable) {
                Log.e("ERROR", t.message.toString())
            }

        })
    }
}