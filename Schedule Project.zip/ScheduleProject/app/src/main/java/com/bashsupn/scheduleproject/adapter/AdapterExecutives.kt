package com.bashsupn.scheduleproject.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.manager.EditExecutiveActivity
import com.bashsupn.scheduleproject.model.UserResponse

class AdapterExecutives(private val dataList: ArrayList<UserResponse>): RecyclerView.Adapter<AdapterExecutives.ViewHolderData>(){


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolderData {
        val layout = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)

        return ViewHolderData(layout)
    }

    override fun onBindViewHolder(holder: ViewHolderData, position: Int) {

        val item=dataList[position]
        holder.nama.text=item.name
        holder.email.text=item.email

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.context, EditExecutiveActivity::class.java)

            intent.putExtra("id", item.id.toString())
            intent.putExtra("name", item.name)
            intent.putExtra("email", item.email)
            holder.context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int = dataList.size

    class ViewHolderData(itemView: View): RecyclerView.ViewHolder(itemView) {
        val nama: TextView =itemView.findViewById(R.id.mTitle)
        val email: TextView =itemView.findViewById(R.id.mTgl)
        val context = itemView.context
    }



}