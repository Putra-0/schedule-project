package com.bashsupn.scheduleproject.model

data class Data(
    val created_at: String,
    val deleted_at: Any,
    val id: Int,
    val name: String,
    val updated_at: String,
    val user: UserResponse,
    val user_id: Int
)