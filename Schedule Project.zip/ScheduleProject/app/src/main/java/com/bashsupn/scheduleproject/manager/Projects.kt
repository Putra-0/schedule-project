package com.bashsupn.scheduleproject.manager

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.adapter.AdapterProject
import com.bashsupn.scheduleproject.api.RClient
import com.bashsupn.scheduleproject.model.ProjectResponse
import com.bashsupn.scheduleproject.sharedpreferences.PrefManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Projects : AppCompatActivity() {

    private lateinit var prefManager: PrefManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_projects)
        getProject()

        val project = findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.addingBtn)
        project.setOnClickListener{
            val Intent = Intent(this,AddProject::class.java)
            startActivity(Intent)
        }

    }

    private fun getProject() {
        prefManager = PrefManager(this)
        val api = RClient.Create(this)
        val listData = ArrayList<ProjectResponse>()
        val rvproject = findViewById<RecyclerView>(R.id.rv_project)
        rvproject.setHasFixedSize(true)
        rvproject.layoutManager = LinearLayoutManager(this)
        val callData = api.getProjects()

        callData.enqueue(object : Callback<ArrayList<ProjectResponse>> {
            override fun onResponse(
                call: Call<ArrayList<ProjectResponse>>,
                response: Response<ArrayList<ProjectResponse>>,
            ) {
                val data = response.body()
                data?.let { listData.addAll(it) }
                val adapterData = AdapterProject(listData)
                rvproject.adapter = adapterData
                Log.e("Data", data.toString())

            }

            override fun onFailure(call: Call<ArrayList<ProjectResponse>>, t: Throwable) {
                Log.e("Error", t.message.toString())
            }

        })


    }
}