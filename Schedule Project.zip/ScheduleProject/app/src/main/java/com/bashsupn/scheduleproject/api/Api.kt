package com.bashsupn.scheduleproject.api

import com.bashsupn.scheduleproject.model.FormResponse
import com.bashsupn.scheduleproject.model.LoginResponse
import com.bashsupn.scheduleproject.model.ProjectResponse
import com.bashsupn.scheduleproject.model.UserResponse
import retrofit2.Call
import retrofit2.http.*

interface Api   {
    @FormUrlEncoded
    @POST("manager/login")
    fun login(
        @Field("email") email:String,
        @Field("password") password: String
    ): Call<LoginResponse>


    @GET("manager/users")
    fun getUsers(
    ): Call<ArrayList<UserResponse>>

    @FormUrlEncoded
    @POST("manager/users")
    fun createExecutive(
        @Field("name") name:String,
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("password_confirmation") password_confirmation: String
    ): Call<FormResponse>

    @DELETE("manager/users/{id}")
    fun deleteExecutive(
        @Path("id") id: Int
    ): Call<FormResponse>

    @FormUrlEncoded
    @PUT("manager/users/{id}")
    fun updateExecutive(
        @Path("id") id: Int,
        @Field("name") name:String,
        @Field("email") email: String,
    ): Call<FormResponse>


    @GET("manager/jobs")
    fun getProjects(
    ): Call<ArrayList<ProjectResponse>>


}