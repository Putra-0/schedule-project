package com.bashsupn.scheduleproject.manager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import com.bashsupn.scheduleproject.R
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AddProject : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_project)

        val pelaksana : AutoCompleteTextView = findViewById(R.id.pelaksanaInput)
        val executives = resources.getStringArray(R.array.executives)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, executives)
        pelaksana.setAdapter(adapter)
        pelaksana.setOnItemClickListener { adapterView, view, i, l ->
            Toast.makeText(this, adapterView.getItemAtPosition(i).toString(), Toast.LENGTH_SHORT).show()
        }

        val linearLayout = findViewById<LinearLayout>(R.id.list_activity)
        val button = findViewById<FloatingActionButton>(R.id.add_column)

        button.setOnClickListener {
            val newView = layoutInflater.inflate(R.layout.row_add_activities, null)
            linearLayout.addView(newView)
        }
    }

}