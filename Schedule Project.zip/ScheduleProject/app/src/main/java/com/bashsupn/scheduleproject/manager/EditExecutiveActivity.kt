package com.bashsupn.scheduleproject.manager

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.bashsupn.scheduleproject.R
import com.bashsupn.scheduleproject.api.RClient
import com.bashsupn.scheduleproject.model.FormResponse
import com.google.android.material.textfield.TextInputEditText
import kotlinx.android.synthetic.main.activity_edit_executive.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditExecutiveActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_executive)

        detailExecutive()
        val btnDelete = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_delete_executive)

        btnDelete.setOnClickListener {
           AlertDialog.Builder(this)
               .setTitle("Hapus Pelaksana")
               .setMessage("Apakah anda yakin ingin menghapus pelaksana ini?")
               .setPositiveButton("Ya") { dialog, which ->
                   deleteExecutive()
               }
               .setNegativeButton("Tidak") { dialog, which ->
                   dialog.dismiss()
               }
               .show()
        }

        val btnUpdate = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btn_update_executive)
        btnUpdate.setOnClickListener {
            updateExecutive()
        }
    }

    private fun detailExecutive() {
        val etNama: TextInputEditText = findViewById(R.id.et_nama_executive)
        val etEmail: TextInputEditText = findViewById(R.id.et_email)

        etNama.setText(intent.getStringExtra("name"))
        etEmail.setText(intent.getStringExtra("email"))
    }

    private fun updateExecutive() {

        val etNama = et_nama_executive.text.toString()
        val etEmail = et_email.text.toString()

        val id = intent.extras?.getString("id")

        val api = RClient.Create(this)
        val callData = id?.let { api.updateExecutive(it.toInt(), etNama, etEmail) }
        callData?.enqueue(object : Callback<FormResponse>{
            override fun onResponse(
                call: Call<FormResponse>,
                response: Response<FormResponse>
            ) {
                Log.d("TAG", "onResponse: ${response.body()}")
                val data = response.body()
                if (response.isSuccessful) {
                    Toast.makeText(this@EditExecutiveActivity, data?.message, Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@EditExecutiveActivity, Executives::class.java).also {
                        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this@EditExecutiveActivity, "Gagal mengubah pelaksana", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<FormResponse>, t: Throwable) {
                Toast.makeText(this@EditExecutiveActivity, "Gagal mengubah pelaksana", Toast.LENGTH_SHORT).show()
            }
        })


    }
    private fun deleteExecutive() {
        val id = intent.extras?.getString("id")

        val api = RClient.Create(this)
        val callData = id?.let { api.deleteExecutive(it.toInt()) }

        callData?.enqueue(object : Callback<FormResponse> {
            override fun onResponse(
                call: Call<FormResponse>,
                response: Response<FormResponse>
            ) {
                Log.d("TAG", "onResponse: ${response.body()}")
                val data = response.body()
                if (response.isSuccessful) {
                    Toast.makeText(this@EditExecutiveActivity, data?.message, Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@EditExecutiveActivity, Executives::class.java).also {
                        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this@EditExecutiveActivity, "Gagal menghapus pelaksana", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<FormResponse>, t: Throwable) {
                Toast.makeText(this@EditExecutiveActivity, "Gagal menghapus pelaksana", Toast.LENGTH_SHORT).show()
            }
        })


    }
}