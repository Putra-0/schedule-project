package com.bashsupn.projectschedule.adapter

import android.content.Intent
import android.view.*
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bashsupn.projectschedule.R
import com.bashsupn.projectschedule.executive.DetailProject
import com.bashsupn.projectschedule.models.Projects


class AdapterProject(private val dataList: ArrayList<Projects>) : RecyclerView.Adapter<AdapterProject.ViewHolderData>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderData {
        val layout = LayoutInflater.from(parent.context).inflate(R.layout.adapter_project, parent, false)
        return ViewHolderData(layout)
    }

    override fun onBindViewHolder(holder: ViewHolderData, position: Int) {
        val item = dataList[position]
        holder.nama.text = item.name
        holder.clinet.text = "Client : "+item.client_name
        holder.status.text = "Status : "+item.status

        holder.showPopupMenu.setOnClickListener{
            showPopupMenu(holder.showPopupMenu, position)
        }

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.context, DetailProject::class.java)

            intent.putExtra("id", item.id.toString())
            intent.putExtra("name", item.name)
            intent.putExtra("client_name", item.client_name)
            intent.putExtra("status", item.status)

        }
    }

    override fun getItemCount(): Int = dataList.size

    private fun showPopupMenu(view: View, position: Int) {
        val popupMenu = PopupMenu(view.context, view)
        val inflater = popupMenu.menuInflater
        inflater.inflate(R.menu.show_menu, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener(object : PopupMenu.OnMenuItemClickListener {
            override fun onMenuItemClick(item: MenuItem): Boolean {
                when (item.itemId) {
                    R.id.textView -> {
                        Toast.makeText(view.context, "Anda memilih edit", Toast.LENGTH_SHORT).show()
                        return true
                    }
                    R.id.deletep -> {
                        Toast.makeText(view.context, "Anda memilih delete", Toast.LENGTH_SHORT).show()
                        return true
                    }
                    else -> return false
                }
            }
        })
        popupMenu.show()
    }

    fun updateData(newData: List<Projects>) {
        dataList.clear()
        dataList.addAll(newData)
        notifyDataSetChanged()
    }

    class ViewHolderData(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nama: TextView = itemView.findViewById(R.id.mTitle)
        val clinet: TextView = itemView.findViewById(R.id.mTgl)
        val status: TextView = itemView.findViewById(R.id.mStatus)
        val context = itemView.context

        val showPopupMenu: ImageView = itemView.findViewById(R.id.mMenus)
    }
}