package com.bashsupn.projectschedule.models

data class Role(
    val created_at: String,
    val id: Int,
    val role: String,
    val updated_at: String
)