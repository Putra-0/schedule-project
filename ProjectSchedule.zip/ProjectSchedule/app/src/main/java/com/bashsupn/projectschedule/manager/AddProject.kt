package com.bashsupn.projectschedule.manager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bashsupn.projectschedule.R

class AddProject : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_project)
    }
}