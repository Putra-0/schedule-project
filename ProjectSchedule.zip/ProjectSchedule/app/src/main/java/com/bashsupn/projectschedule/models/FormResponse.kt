package com.bashsupn.projectschedule.models

data class FormResponse(
    val message: String,
    val status: Boolean
)
