package com.bashsupn.projectschedule.api

import com.bashsupn.projectschedule.models.FormResponse
import com.bashsupn.projectschedule.models.LoginResponse
import com.bashsupn.projectschedule.models.ProjectsResponse
import com.bashsupn.projectschedule.models.UsersResponse
import retrofit2.Call
import retrofit2.http.*

interface Api {
    @FormUrlEncoded
    @POST("login")
    fun login(
        @Field("email") email:String,
        @Field("password") password: String
    ): Call<LoginResponse>

    @GET("users")
    fun getUsers(
    ): Call<ArrayList<UsersResponse>>

    @FormUrlEncoded
    @POST("users")
    fun addUser(
        @Field("name") name:String,
        @Field("email") email:String,
        @Field("password") password: String
    ): Call<FormResponse>

    @FormUrlEncoded
    @PUT("users/{id}")
    fun updateUser(
        @Path("id") id: Int,
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<FormResponse>

    @DELETE("users/{id}")
    fun deleteUser(
        @Path("id") id: Int
    ): Call<FormResponse>

    @GET("jobs")
    fun getProjects(
    ): Call<ProjectsResponse>
}